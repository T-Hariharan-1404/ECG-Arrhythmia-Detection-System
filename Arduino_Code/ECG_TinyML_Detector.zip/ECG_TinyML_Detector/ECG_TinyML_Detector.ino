// ================================================================
// FINAL CORRECTED CODE: ECG TinyML Detector (TFLite + Ticker)
// Updated for new TFLite Micro API (ESP32 Core 3.x)
// ================================================================
#include <Arduino.h>
#include <Ticker.h>

// --- TFLite Includes (All required headers for the new API) ---
#include <tensorflow/lite/micro/micro_error_reporter.h> // For error reporting
#include <tensorflow/lite/micro/micro_interpreter.h>      // For running the model
#include <tensorflow/lite/micro/micro_mutable_op_resolver.h> // For loading ops
#include <tensorflow/lite/micro/system_setup.h>         // For TFLite setup
#include <tensorflow/lite/schema/schema_generated.h>    // For the model schema
#include <tensorflow/lite/micro/micro_allocator.h>      // <-- NEW: For memory management

// Your downloaded model file (must be in the same folder)
#include "model_data.h" 

// ---------------- Configuration ----------------
// --- Paste your Colab constants here ---
const float MIN_VAL = -3.7149999141693115; // <-- PASTE YOUR EXACT MIN VALUE
const float MAX_VAL = 3.4649999141693115;  // <-- PASTE YOUR EXACT MAX VALUE
const int WINDOW_SIZE = 180;
const int ADC_PIN = 34; // Use 34 or 35 (the pin you wired)
const int ADC_RESOLUTION = 4095;
const int NUM_CLASSES = 4;

// ---------------- Globals ----------------
float input_buffer[WINDOW_SIZE];
volatile int buffer_index = 0;
Ticker ticker; // Software timer for 250Hz sampling

// --- TensorFlow Lite Micro Globals (Updated for new API) ---
namespace {
    // FIX 1: TFLite Error Reporter setup
    tflite::ErrorReporter* error_reporter = nullptr;
    tflite::MicroErrorReporter micro_error_reporter; // This is the concrete instance

    // FIX 2: TFLite Allocator setup (replaces passing the arena directly)
    tflite::MicroAllocator* allocator = nullptr;
    constexpr int kTensorArenaSize = 20 * 1024; // 20KB Arena
    uint8_t tensor_arena[kTensorArenaSize];

    // Standard TFLite objects
    const tflite::Model* model = nullptr;
    tflite::MicroInterpreter* interpreter = nullptr;
    TfLiteTensor* input = nullptr;
    TfLiteTensor* output = nullptr;
    
    // Use MicroMutableOpResolver
    tflite::MicroMutableOpResolver<10> resolver;
}

// ---------------- Sampling ISR (with Normalization) ----------------
void sampleECG() {
    int raw_adc = analogRead(ADC_PIN);
    float voltage = (float)raw_adc * (3.3 / ADC_RESOLUTION);
    float normalized = (voltage - MIN_VAL) / (MAX_VAL - MIN_VAL);

    if (buffer_index < WINDOW_SIZE) {
        input_buffer[buffer_index++] = normalized;
    }
}

// ---------------- Setup ----------------
void setup() {
    Serial.begin(115200);
    delay(2000); // Wait for Serial Monitor
    Serial.println("\n--- Setup Started ---");
    
    analogReadResolution(12);
    pinMode(ADC_PIN, INPUT);

    // FIX 3: Initialize the error reporter
    error_reporter = &micro_error_reporter;
    tflite::InitializeTarget(); // Required by new TFLite/ESP32 setup

    // --- Load the TFLite model ---
    // Use the exact array name from your model_data.h file (it has a 'g_' prefix)
    model = tflite::GetModel(g_ecg_arrhythmia_model_data); 
    Serial.println("1. Model loaded.");

    if (model->version() != TFLITE_SCHEMA_VERSION) {
        error_reporter->Report("ERROR: Model version mismatch!");
        while (1);
    }
    Serial.println("2. Model version checked.");

    // --- Add required ops for the CNN ---
    resolver.AddConv2D();
    resolver.AddMaxPool2D();
    resolver.AddFullyConnected();
    resolver.AddSoftmax();
    resolver.AddReshape();
    Serial.println("3. Ops resolved.");

    // FIX 4: Create the MicroAllocator (New API Step)
    allocator = tflite::MicroAllocator::Create(tensor_arena, kTensorArenaSize, error_reporter);
    if (allocator == nullptr) {
        error_reporter->Report("ERROR: MicroAllocator creation failed!");
        while(1);
    }
    Serial.println("4. Allocator created.");

    // FIX 5: Initialize interpreter (New API Constructor)
    interpreter = new tflite::MicroInterpreter(
        model, resolver, allocator, error_reporter);
    Serial.println("5. Interpreter created.");

    if (interpreter->AllocateTensors() != kTfLiteOk) {
        error_reporter->Report("ERROR: Tensor allocation failed! (Increase kTensorArenaSize)");
        while (1);
    }
    Serial.println("6. Tensors allocated.");

    input = interpreter->input(0);
    output = interpreter->output(0);
    Serial.println("TFLite Model Initialized Successfully.");

    // --- Start sampling at 250Hz ---
    ticker.attach_ms(4, sampleECG); // 4ms interval = 250Hz
    Serial.println("Sampling Timer Started.");
}

// ---------------- Main Loop ----------------
void loop() {
    // Check if the buffer is full
    if (buffer_index >= WINDOW_SIZE) {
        ticker.detach(); // Pause sampling during inference

        // Copy collected samples to TFLite input tensor
        for (int i = 0; i < WINDOW_SIZE; i++)
            input->data.f[i] = input_buffer[i];

        // Run inference
        if (interpreter->Invoke() != kTfLiteOk) {
            error_reporter->Report("ERROR: Inference failed!");
        } else {
            // Find predicted class
            float max_prob = 0;
            int predicted_class = -1;
            for (int i = 0; i < NUM_CLASSES; i++) {
                if (output->data.f[i] > max_prob) {
                    max_prob = output->data.f[i];
                    predicted_class = i;
                }
            }

            // Print results
            Serial.print("Pred: "); Serial.print(predicted_class);
            Serial.print(" (P: "); Serial.print(max_prob * 100); Serial.print("%) -> ");

            if (predicted_class == 0) Serial.println("NORMAL");
            else if (predicted_class == 1) Serial.println("SVEB");
            else if (predicted_class == 2) Serial.println("!!! VEB ALERT (V) !!!");
            else Serial.println("OTHER/UNKNOWN");
        }

        // Reset buffer and resume sampling
        buffer_index = 0;
        ticker.attach_ms(4, sampleECG);
    }

    delay(50);
}